# Viroz Meeting Manager
This plugin will help you make calendars with custom avilability rules that will let you organize you service time slots and their availability for you website visitors and users.


# After installations
1. Make sure you have the timezone of you website set in the settings page of you wp admin
2. Update the permalink structure in settings > Permalinks if calendars show a #404 error
3. Be sure to add the VZ Calendar Block to you calendar design.

